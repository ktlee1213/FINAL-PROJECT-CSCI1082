package Truck;
import Register.Calculator;
import Register.Starters;

public class Driver {
	public static void main(String[] args) {
		Starters mainMenu = new Starters();
		Menu newMenu = new Menu();
		BurgerMenu newBurger = new BurgerMenu();
		newBurger.burgerToppings.toString();
		PizzaMenu newPizza = new PizzaMenu();
		newPizza.pizzaToppings.toString();
		TacoMenu newTaco = new TacoMenu();
		newTaco.tacoToppings.toString();
		DessertMenu newDessert = new DessertMenu();
		newDessert.dessertToppings.toString();
		Calculator newCalculator = new Calculator();
		}
	}

